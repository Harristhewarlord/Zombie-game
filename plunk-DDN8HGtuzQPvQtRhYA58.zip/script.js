let newGame = document.getElementById('new-game-button');
let title = document.getElementById('title');
let subTitle = document.getElementById('sub-title');
let axeButton = document.getElementById('slightly-damaged-axe-button');
let pocketKnife = document.getElementById('pocket-knife-button');
let axeChoice = document.getElementById('axe-choice');
let story = document.getElementById('story');
let pocketKnifeChoice = document.getElementById('pocket-knife-choice');
let gameOver = document.getElementById('over');
let aliveDisplay = document.getElementById('alive');
let note = document.getElementById('note');
let backStory = document.getElementById('backstory');
let backStoryStory = document.getElementById('backstory-story');
let backStoryContinue = document.getElementById('backstory-continue');
let next = document.getElementById('next-button');
let continueStory = document.getElementById('continue-story');
let storyContinued = document.getElementById('story-continued');
let attackButton = document.getElementById('attack-button');




axeButton.style.display = 'none';
pocketKnife.style.display = 'none';
axeChoice.style.display = 'none';
pocketKnifeChoice.style.display = 'none';
story.style.display = 'none';
gameOver.style.display = 'none';
aliveDisplay.style.display = 'none';
note.style.display = 'none';
backStory.style.display = 'none';
backStoryStory.style.display = 'none';
backStoryContinue.style.display = 'none';
next.style.display = 'none';
continueStory.style.display = 'none';
storyContinued.style.display = 'none';
attackButton.style.display = 'none';


newGame.addEventListener('click', function() {

  title.style.display = 'none';
  subTitle.style.display = 'none';
  axeButton.style.display = 'block';
  newGame.style.display = 'none';
  pocketKnife.style.display = 'block';
  story.style.display = 'block';
  aliveDisplay.style.display = 'none';
  gameOver.style.display = 'none';
  backStoryStory.style.display = 'none';
  backStoryContinue.style.display = 'none';
  next.style.display = 'none';
  continueStory.style.display = 'none';
  storyContinued.style.display = 'none';
  attackButton.style.display = 'none';

})


axeButton.addEventListener('click', function() {

  axeChoice.style.display = 'block';
  story.style.display = 'none';
  axeButton.style.display = 'none';
  pocketKnife.style.display = 'none';
  note.style.display = 'block';
  backStoryStory.style.display = 'none';
  backStoryContinue.style.display = 'none';
  next.style.display = 'none';
  continueStory.style.display = 'none';
  storyContinued.style.display = 'none';
  attackButton.style.display = 'none';

  if (Math.random() * 11 < 5) {

        gameOver.style.display = 'block',
        newGame.style.display = 'block',
        axeChoice.style.display = 'none';
        backStoryStory.style.display = 'none';
        backStoryContinue.style.display = 'none';
        next.style.display = 'none';
        continueStory.style.display = 'none';
        storyContinued.style.display = 'none';
        attackButton.style.display = 'none';

    }

  if(Math.random() * 11 >= 5) {

        newGame.style.display = 'none',
        gameOver.style.display = 'none',
        aliveDisplay.style.display = 'block',
        axeChoice.style.display = 'none';
        backStory.style.display = 'block';
        backStoryStory.style.display = 'none';
        backStoryContinue.style.display = 'none';
        next.style.display = 'none';
        continueStory.style.display = 'block';
        storyContinued.style.display = 'none';
        attackButton.style.display = 'none';

  }

})



pocketKnife.addEventListener('click', function() {

  pocketKnifeChoice.style.display = 'block';
  story.style.display = 'none';
  pocketKnife.style.display = 'none';
  axeButton.style.display = 'none';
  note.style.display = 'block';
  backStoryStory.style.display = 'none';
  backStoryContinue.style.display = 'none';
  next.style.display = 'none';
  continueStory.style.display = 'none';
  storyContinued.style.display = 'none';
  attackButton.style.display = 'none';

  if (Math.random() * 11 < 5) {

        gameOver.style.display = 'block',
        newGame.style.display = 'block',
        pocketKnifeChoice.style.display = 'none';
        backStoryStory.style.display = 'none';
        backStoryContinue.style.display = 'none';
        next.style.display = 'none';
        continueStory.style.display = 'none';
        storyContinued.style.display = 'none';
        attackButton.style.display = 'none';

    }

  if (Math.random() * 11 >= 5) {

        newGame.style.display = 'none',
        gameOver.style.display = 'none',
        aliveDisplay.style.display = 'block',
        pocketKnifeChoice.style.display = 'none';
        backStory.style.display = 'block';
        backStoryStory.style.display = 'none';
        backStoryContinue.style.display = 'none';
        next.style.display = 'none';
        continueStory.style.display = 'block';
        storyContinued.style.display = 'none';
        attackButton.style.display = 'none';

  }

})



backStory.addEventListener('click', function() {

  alive.style.display = 'none',
  axeButton.style.display = 'none';
  pocketKnife.style.display = 'none';
  axeChoice.style.display = 'none';
  pocketKnifeChoice.style.display = 'none';
  story.style.display = 'none';
  gameOver.style.display = 'none';
  aliveDisplay.style.display = 'none';
  note.style.display = 'none';
  backStoryStory.style.display = 'block';
  backStoryContinue.style.display = 'none';
  next.style.display = 'block';
  continueStory.style.display = 'none';
  backStory.style.display = 'none';
  storyContinued.style.display = 'none';
  attackButton.style.display = 'none';

})



next.addEventListener('click', function() {

  alive.style.display = 'none',
  axeButton.style.display = 'none';
  pocketKnife.style.display = 'none';
  axeChoice.style.display = 'none';
  pocketKnifeChoice.style.display = 'none';
  story.style.display = 'none';
  gameOver.style.display = 'none';
  aliveDisplay.style.display = 'none';
  note.style.display = 'none';
  backStory.style.display = 'none';
  backStoryStory.style.display = 'none';
  backStoryContinue.style.display = 'block';
  next.style.display = 'none';
  continueStory.style.display = 'block';
  storyContinued.style.display = 'none';
  attackButton.style.display = 'none';

})



continueStory.addEventListener('click', function() {

  alive.style.display = 'none',
  axeButton.style.display = 'none';
  pocketKnife.style.display = 'none';
  axeChoice.style.display = 'none';
  pocketKnifeChoice.style.display = 'none';
  story.style.display = 'none';
  gameOver.style.display = 'none';
  aliveDisplay.style.display = 'none';
  note.style.display = 'none';
  backStory.style.display = 'none';
  backStoryStory.style.display = 'none';
  backStoryContinue.style.display = 'none';
  next.style.display = 'none';
  continueStory.style.display = 'none';
  storyContinued.style.display = 'block';
  attackButton.style.display = 'block';

})

